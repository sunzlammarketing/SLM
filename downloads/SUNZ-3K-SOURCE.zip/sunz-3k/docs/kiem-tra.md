# Kiểm tra bản dựng nháp

- Đã xem khung hình video tham khảo tại các mốc từ đầu đến cuối. File mẫu: 58 giây, 2160 × 3840, 30 fps. Không đánh giá chất giọng/nhạc mẫu vì chưa nghe được trong công cụ hiện có.
- Đã chạy TypeScript (`npm run check`): thành công.
- Đã khởi chạy Remotion Studio và kiểm tra HTTP 200. Không có trình duyệt tương tác tích hợp trong chat; kiểm tra hình ảnh bằng Remotion still.
- Đã render và xem cả 7 cảnh: Hook (3s), Formula (7s), CheckWords (14.17s), Experience (26.67s), Match (36s), Recap (42s), Outro (46.67s). Font tiếng Việt hiển thị đầy đủ, không phát hiện chữ chồng/tràn ở các khung đã xem. Chưa xem mọi khung hình liên tiếp bằng mắt.
- Màu chính #2E2A8C và #FF6A55. Thành phần chính cách mép trái 180px, phải 220px; phần nội dung chính tránh vùng đáy. Mức che của từng giao diện nền tảng có thể khác nhau.
- Nhạc và sfx PCM 48 kHz tự tạo. Đã đo không clipping ở nguồn: music peak -17.4 dBFS; sfx peak -14.8 dBFS. Bản mix giảm âm lượng lần lượt còn 0.16 và 0.4.
- Chưa có giọng đọc 3K: chưa thể kiểm tra đồng bộ lời–hình, ducking hay loudness tổng thể với giọng đọc.
- Chưa có tệp ảnh gốc: chưa thể kiểm tra logo bản xuất. Nhãn chữ SUNZ là chỗ giữ tạm, không phải logo tái tạo.
- Bản xuất gắn nhãn NHÁP. Không phải video hoàn chỉnh để đăng.
- Thông số MP4 thực tế sau render được lưu trong mp4-metadata.json khi quá trình render hoàn tất.

## Kết quả MP4 đã xuất

- H.264, 2160 × 3840 px, 60/1 fps, 2880 khung hình, đúng 48.000 giây.
- AAC stereo 48 kHz. Peak track mix -24.3 dBFS, không clipping; mức nhạc hiện để nền nhỏ, cần cân lại khi có giọng đọc.
- Đã lấy ảnh từ MP4 đã mã hóa tại 26.7 giây để đối chiếu với cảnh Kể cảm nhận.
- Người dùng xác nhận sẽ gửi bản thu 3K; không tạo giọng tổng hợp.
