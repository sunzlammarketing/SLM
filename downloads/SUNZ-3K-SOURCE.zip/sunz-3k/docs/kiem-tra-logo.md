# Kiểm tra bản có logo

- Đã nhận ZIP của người dùng, sao chép đúng PNG 1254 × 1254 vào public/brand/logo.png. SHA256 89621d2b6918f00c789d80e29ceb9cf8d469ddd8ce39dee746852b8263e4aa38; trùng nguyên byte trong ZIP.
- Không chỉnh ảnh logo; chỉ đặt bằng Img/object-fit contain ở header 240 × 240 và outro 720 × 720.
- Đã xem ảnh nguồn và ba ảnh render: Hook nền sáng (frame 180), Formula nền tím (frame 620), Outro (frame 2860). Logo không bị méo hoặc cắt; đã bỏ nhãn chờ logo và chữ giữ chỗ. Chữ thông điệp và CTA không chồng lên logo ở các ảnh đã kiểm tra.
- TypeScript chạy thành công sau cập nhật logo, header, outro và props.
- Voice/mix và mốc timeline giữ như bản có voice trước. Độ chính xác căn theo bảng giây nguyên người dùng gửi; chưa kiểm tra nghe toàn bộ hay đối chiếu từng từ bằng ASR.
- Timeline 3000 frame ở 60 fps, native 2160 × 3840. Track âm thanh stereo 48 kHz. Metadata, giải mã và so sánh audio của bản mới được ghi thêm sau render.

## Kết quả MP4

- Render đủ 3000 frame, H.264 2160 × 3840, 60/1 fps; thời lượng hình 50.000 s, container 50.005 s do đệm AAC. AAC stereo 48 kHz, bắt đầu tại 0.
- Giải mã toàn bộ video hoàn tất exit 0, không báo lỗi. Đã lấy ảnh từ MP4 tại 47.67 s và xem lại logo/outro sau mã hóa: giữ đúng bố cục, không còn chữ giữ chỗ hay nhãn chờ logo.
- AAC đã giải mã đối chiếu mix gốc không dịch thời gian: tương quan 0.999975 qua 800000 mẫu mono 16 kHz, xác nhận đúng track voice + nhạc + hiệu ứng.
- Bản mix giữ như lần trước: AAC đo được -16.73 LUFS, true peak -4.30 dBTP, không clipping. Chưa kiểm tra nghe chủ quan toàn bộ.
