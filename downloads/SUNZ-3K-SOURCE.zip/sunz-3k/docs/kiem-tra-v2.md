# Kiểm tra bản có voice

- Timeline: 3000 frame / 60 fps = 50 s. Bảy cảnh độc lập, các mốc K được căn theo giây tác giả cung cấp, chia 1.15 rồi làm tròn frame.
- Voice nguồn 54.204063 s; bản xử lý 47.136750 s. Không cắt câu, không dùng giọng tổng hợp. Dư 2.86 s nhạc outro.
- TypeScript đã chạy thành công sau cập nhật timeline và @remotion/media.
- Studio đã khởi chạy. Công cụ chat không có trình duyệt tương tác tích hợp; dùng ảnh render để kiểm tra.
- Đã xem ảnh Formula, Kể cảm nhận, Khớp công bố sau khi đổi bố cục/mốc. Dấu tiếng Việt đầy đủ, chưa thấy tràn/chồng chữ ở các ảnh đã kiểm tra. Cảnh Kiểm từ được đổi thời gian, giữ bố cục đã kiểm tra ở bản trước.
- Mix WAV: -16.71 LUFS, -4.31 dBTP theo FFmpeg loudnorm đo đầu vào. Không clipping. Nhạc dùng sidechaincompress theo voice, không chỉ hạ âm lượng cố định. Không tuyên bố đã nghe kiểm tra toàn bộ âm thanh.
- Chưa có logo gốc dạng tệp. Bản xuất có dòng “BẢN CÓ VOICE · CHỜ LOGO GỐC”.
- Chưa kiểm tra pháp lý cho sản phẩm cụ thể; nội dung voice gốc giữ nguyên. Các điểm cần điều chỉnh khi thu lại ghi trong loi-doc.txt.
- Sau khi render: lưu metadata-v2.json, kiểm tra giải mã và đo track AAC thực tế.

## Kết quả bản MP4 đã xuất

- Render thành công đủ 3000 frame. Video H.264 2160 × 3840, 60/1 fps, thời lượng hình chính xác 50.000 s. Track AAC stereo 48 kHz bắt đầu tại 0; container 50.005 s do đệm AAC.
- Giải mã toàn bộ MP4 bằng FFmpeg hoàn tất với exit 0, không báo lỗi.
- Track AAC thực tế đo được -16.73 LUFS, true peak -4.30 dBTP, không clipping.
- So sánh track AAC đã giải mã với mix nguồn ở mono 16 kHz, không dịch thời gian: tương quan 0.999975 qua 800000 mẫu. Xác nhận bản xuất chứa đúng mix mới, không phải nhạc đơn của bản nháp cũ.
- Đã lấy và xem ảnh từ MP4 tại 28.7 s (ví dụ cảm nhận) để đối chiếu chữ và bố cục sau mã hóa.
- Chưa có kiểm tra nghe chủ quan toàn bộ, đồng bộ từng từ hay logo gốc. Các mốc cảnh dựa trên bảng người dùng cung cấp.
