# Trạng thái bản voice hiện tại

Đã nhận 13 mốc giây nguyên từ người dùng, đúng nội dung 3K. Các mốc đã chuyển sang tốc độ 1.15× và áp dụng vào timeline 50 giây. Không cần chờ mô hình ASR cho bước căn theo ý này.

Bản voice gốc được giữ tại public/audio/voice-original.mp3; bản xử lý dài 47.136750 giây. Mix stereo có nhạc tự giảm theo lời đọc và hiệu ứng tự tạo. Xem chia-canh.md và user-voice-cues.json.

Đây là căn theo mốc người dùng, chưa phải đồng bộ từng từ đã được nghe/ASR xác minh. Một số câu hứa hẹn trong voice vẫn giữ nguyên, có ghi chú bổ sung trên hình và trong loi-doc.txt.

Đã bổ sung logo PNG gốc từ ZIP người dùng cung cấp. Bản mới giữ nguyên voice/mix và mốc đã dùng, bỏ nhãn chờ logo.
