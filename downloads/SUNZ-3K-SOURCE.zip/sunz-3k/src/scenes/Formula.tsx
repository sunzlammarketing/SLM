import {interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {BrandProps,Shell,Reveal,Title,Accent,Card,C,clamp} from '../design';
export const Formula=({logoFile}:BrandProps)=>{const f=useCurrentFrame();const {fps}=useVideoConfig();return <Shell dark logoFile={logoFile} step="01 / CÔNG THỨC 3K">
<Reveal><Title>Một công thức.<br/><Accent>Ba bước rà soát.</Accent></Title></Reveal>
<div style={{height:640,position:'relative',marginTop:80}}>
<div style={{position:'absolute',top:60,fontSize:128,fontWeight:800,lineHeight:1.4,opacity:interpolate(f,[4.1*fps,4.35*fps],[1,0],clamp)}}>RÀ LẠI<br/><Accent>TRƯỚC KHI ĐĂNG</Accent></div>
<Reveal at={(11-6)/1.15} style={{position:'absolute',inset:0,fontSize:520,lineHeight:1.2,fontWeight:800,color:C.orange}}>3K<span style={{fontSize:75,color:'white',fontWeight:600}}> / nhớ để dùng</span></Reveal>
</div>
<div style={{display:'flex',gap:24,marginTop:30}}><Reveal at={.55} style={{flex:1}}><Card dark style={{padding:38,fontSize:66,fontWeight:700}}>01<br/><br/>Kiểm<br/>từ</Card></Reveal><Reveal at={.9} style={{flex:1}}><Card dark style={{padding:38,fontSize:66,fontWeight:700}}>02<br/><br/>Kể cảm<br/>nhận</Card></Reveal><Reveal at={1.25} style={{flex:1}}><Card dark style={{padding:38,fontSize:66,fontWeight:700}}>03<br/><br/>Khớp<br/>công bố</Card></Reveal></div>
<Reveal at={1.6} style={{fontSize:70,lineHeight:1.4,marginTop:90}}>Giúp giảm rủi ro.<br/>Không bảo đảm quảng cáo được duyệt.</Reveal>
</Shell>};
