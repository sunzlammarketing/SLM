import {BrandProps,Shell,Reveal,Title,Accent,Bottle,Card,C} from '../design';
export const Hook=({logoFile}:BrandProps)=><Shell logoFile={logoFile} step="00 / TRƯỚC KHI ĐĂNG">
<Reveal><Title>Content mỹ phẩm<br/><Accent>bị từ chối?</Accent></Title></Reveal>
<Reveal at={.45} style={{display:'flex',alignItems:'center',gap:50,marginTop:110}}><Bottle/><div style={{flex:1}}><Card><div style={{fontSize:72,fontWeight:800,color:C.orange}}>XEM LẠI<br/>NỘI DUNG</div><div style={{fontSize:52,lineHeight:1.5,marginTop:30}}>Lời hứa có<br/>quá mức?</div></Card></div></Reveal>
<Reveal at={2} style={{fontSize:86,fontWeight:600,marginTop:110,lineHeight:1.45}}>Bắt đầu bằng<br/>3 bước rà soát.</Reveal>
</Shell>;
