import {AbsoluteFill,Composition,Folder,Series,staticFile,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {BrandProps} from './design';
import {Hook} from './scenes/Hook';
import {Formula} from './scenes/Formula';
import {CheckWords} from './scenes/CheckWords';
import {Experience} from './scenes/Experience';
import {Match} from './scenes/Match';
import {Recap} from './scenes/Recap';
import {Outro} from './scenes/Outro';
export const Video=({logoFile,voiceFile,draft=false}:BrandProps)=>{const {fps}=useVideoConfig();return <AbsoluteFill>
<Series>
<Series.Sequence name="Hook · 0–6s nguồn" durationInFrames={313*fps/60} premountFor={fps}><Hook logoFile={logoFile}/></Series.Sequence>
<Series.Sequence name="3K · 6–14s nguồn" durationInFrames={417*fps/60} premountFor={fps}><Formula logoFile={logoFile}/></Series.Sequence>
<Series.Sequence name="Kiểm từ · 14–25s nguồn" durationInFrames={574*fps/60} premountFor={fps}><CheckWords logoFile={logoFile}/></Series.Sequence>
<Series.Sequence name="Kể cảm nhận · 25–37s nguồn" durationInFrames={626*fps/60} premountFor={fps}><Experience logoFile={logoFile}/></Series.Sequence>
<Series.Sequence name="Khớp công bố · 37–46s nguồn" durationInFrames={470*fps/60} premountFor={fps}><Match logoFile={logoFile}/></Series.Sequence>
<Series.Sequence name="Nhớ 3K · 46–51s nguồn" durationInFrames={261*fps/60} premountFor={fps}><Recap logoFile={logoFile}/></Series.Sequence>
<Series.Sequence name="SUNZ outro · 51s nguồn" durationInFrames={339*fps/60} premountFor={fps}><Outro logoFile={logoFile}/></Series.Sequence>
</Series>
<Audio src={staticFile(voiceFile||'audio/mix.wav')} premountFor={fps}/>
{draft?<div style={{position:'absolute',bottom:390,left:180,fontFamily:'Be Vietnam Pro',fontSize:28,color:'#FF6A55',background:'#ffffffee',padding:'15px 28px',borderRadius:15}}>BẢN XEM TRƯỚC</div>:null}
</AbsoluteFill>};
export const Root=()=> <><Composition id="SUNZ3K" component={Video} width={2160} height={3840} fps={60} durationInFrames={3000} defaultProps={{draft:false,logoFile:'brand/logo.png',voiceFile:'audio/mix.wav'}}/><Folder name="Scenes">
<Composition id="Hook" component={Hook} width={2160} height={3840} fps={60} durationInFrames={313} defaultProps={{logoFile:'brand/logo.png'}}/>
<Composition id="Formula" component={Formula} width={2160} height={3840} fps={60} durationInFrames={417} defaultProps={{logoFile:'brand/logo.png'}}/>
<Composition id="CheckWords" component={CheckWords} width={2160} height={3840} fps={60} durationInFrames={574} defaultProps={{logoFile:'brand/logo.png'}}/>
<Composition id="Experience" component={Experience} width={2160} height={3840} fps={60} durationInFrames={626} defaultProps={{logoFile:'brand/logo.png'}}/>
<Composition id="Match" component={Match} width={2160} height={3840} fps={60} durationInFrames={470} defaultProps={{logoFile:'brand/logo.png'}}/>
<Composition id="Recap" component={Recap} width={2160} height={3840} fps={60} durationInFrames={261} defaultProps={{logoFile:'brand/logo.png'}}/>
<Composition id="Outro" component={Outro} width={2160} height={3840} fps={60} durationInFrames={339} defaultProps={{logoFile:'brand/logo.png'}}/>
</Folder></>;
