import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import '@fontsource/be-vietnam-pro/vietnamese-400.css';
import '@fontsource/be-vietnam-pro/vietnamese-600.css';
import '@fontsource/be-vietnam-pro/vietnamese-700.css';
import '@fontsource/be-vietnam-pro/vietnamese-800.css';
import '@fontsource/be-vietnam-pro/latin-400.css';
import '@fontsource/be-vietnam-pro/latin-600.css';
import '@fontsource/be-vietnam-pro/latin-700.css';
import '@fontsource/be-vietnam-pro/latin-800.css';
export const C={purple:'#2E2A8C',orange:'#FF6A55',cream:'#F8F7F2',ink:'#222139'};
export const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
export type BrandProps={logoFile?:string;voiceFile?:string;draft?:boolean};
export const Shell:React.FC<{dark?:boolean;step:string;children:React.ReactNode;logoFile?:string;hideHeader?:boolean}>=({dark,step,children,logoFile,hideHeader=false})=>{
 const f=useCurrentFrame();const {durationInFrames}=useVideoConfig();
 return <AbsoluteFill style={{background:dark?C.purple:C.cream,color:dark?'white':C.ink,fontFamily:'Be Vietnam Pro',overflow:'hidden'}}>
 <div style={{position:'absolute',width:1500,height:1500,borderRadius:'50%',border:`2px solid ${dark?'#ffffff0c':'#2e2a8c0b'}`,right:-800,top:300}}/>
 <div style={{position:'absolute',width:1100,height:1100,borderRadius:'50%',background:dark?'#ff6a5508':'#ff6a5507',left:-650,bottom:200}}/>
 {!hideHeader?<div style={{position:'absolute',left:180,top:230,display:'flex',alignItems:'center',gap:36}}>
 {logoFile?<Img src={staticFile(logoFile)} style={{width:240,height:240,objectFit:'contain'}}/>:null}
 <div style={{fontSize:40,fontWeight:800,letterSpacing:3}}>CONTENT MỸ PHẨM<div style={{fontSize:28,fontWeight:400,letterSpacing:2,marginTop:12}}>CÔNG THỨC 3K</div></div></div>:null}
 <div style={{position:'absolute',left:180,right:220,top:650,bottom:650}}>{children}</div>
 <div style={{position:'absolute',left:180,right:220,bottom:580,fontSize:30,letterSpacing:3,opacity:.65}}>{step}<div style={{marginTop:32,height:6,background:dark?'#ffffff22':'#2e2a8c18'}}><div style={{height:'100%',width:`${interpolate(f,[0,durationInFrames],[0,100],clamp)}%`,background:C.orange}}/></div></div>
 </AbsoluteFill>;
};
export const Reveal:React.FC<{at?:number;children:React.ReactNode;style?:React.CSSProperties}>=({at=0,children,style})=>{const f=useCurrentFrame();const {fps}=useVideoConfig();return <div style={{opacity:interpolate(f,[at*fps,at*fps+.25*fps],[0,1],clamp),translate:`0 ${interpolate(f,[at*fps,at*fps+.6*fps],[80,0],clamp)}px`,...style}}>{children}</div>};
export const Title:React.FC<{children:React.ReactNode}>=({children})=><div style={{fontSize:164,fontWeight:800,lineHeight:1.22,letterSpacing:-5}}>{children}</div>;
export const Accent:React.FC<{children:React.ReactNode}>=({children})=><span style={{color:C.orange}}>{children}</span>;
export const Tag:React.FC<{children:React.ReactNode}>=({children})=><div style={{display:'inline-block',background:C.orange,color:'white',padding:'20px 38px',borderRadius:60,fontSize:42,fontWeight:800,marginBottom:52}}>{children}</div>;
export const Card:React.FC<{children:React.ReactNode;dark?:boolean;style?:React.CSSProperties}>=({children,dark,style})=><div style={{background:dark?'#ffffff10':'white',border:`2px solid ${dark?'#ffffff25':'#2e2a8c12'}`,borderRadius:48,padding:64,...style}}>{children}</div>;
export const Tick:React.FC<{at?:number}>=({at=0})=>{const f=useCurrentFrame();const {fps}=useVideoConfig();return <svg width="100" height="100" viewBox="0 0 100 100"><circle cx="50" cy="50" r="46" fill={C.orange}/><path d="M26 50 L43 67 L75 33" fill="none" stroke="white" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="85" strokeDashoffset={interpolate(f,[at*fps,at*fps+30],[85,0],clamp)}/></svg>};
export const Bottle=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();return <svg width="580" height="860" viewBox="0 0 580 860" style={{rotate:`${interpolate(f,[0,fps*1],[9,-4],clamp)}deg`}}><rect x="185" y="15" width="210" height="125" rx="22" fill={C.purple}/><rect x="120" y="135" width="340" height="670" rx="90" fill="white" stroke={C.purple} strokeWidth="10"/><rect x="140" y="310" width="300" height="300" rx="24" fill={C.orange}/><path d="M285 370 C190 480 240 540 285 540 C350 540 370 480 285 370" fill="white"/><text x="290" y="685" textAnchor="middle" fontFamily="Be Vietnam Pro" fontSize="40" fontWeight="700" fill={C.purple}>MỸ PHẨM</text></svg>};
