# SUNZ — Công thức 3K / bản có logo và voice

Remotion dọc 2160 × 3840 px, 60 fps, 50 giây. Logo PNG gốc do người dùng cung cấp, voice thật tăng tốc 1.15× giữ cao độ, nhạc và hiệu ứng tự tạo. Các cảnh đã căn theo 13 mốc giây người dùng gửi. Không còn nhãn chờ logo.

## Chạy và chỉnh sửa

Yêu cầu Node.js 22+, npm, Python 3 và FFmpeg nếu muốn tái tạo âm thanh. Dùng checkout hiện tại; không cần tạo Git worktree.

```bash
npm ci
npm run studio
npm run check
npm run render
```

Studio có composition SUNZ3K và 7 cảnh riêng. `src/Root.tsx` chứa timeline, kích thước và fps; `src/scenes/` chứa từng cảnh; `src/design.tsx` chứa màu, font, header và các thành phần vector. Hoạt họa tính theo frame, không dùng CSS animation hay phóng một ảnh cho toàn cảnh.

Font Be Vietnam Pro được đóng gói qua @fontsource, bao gồm tiếng Việt, không cần kết nối Google Fonts khi render. `/usr/bin/chromium` được dùng nếu có; máy khác để Remotion chọn trình duyệt mặc định.

## Logo

`public/brand/logo.png` là PNG 1254 × 1254 lấy nguyên byte từ ZIP người dùng gửi. Không vẽ lại, đổi màu, xóa nền, cắt ảnh hoặc bóp méo tỷ lệ. Header dùng ảnh 240 × 240, outro 720 × 720, object-fit contain. Xem `docs/logo-asset.json` để kiểm tra hash. Nền trắng của logo được giữ như bản gốc.

Đổi logo bằng cách thay file này hoặc đổi prop `logoFile` trong Root.tsx. Các cảnh cũng đăng ký logo mặc định để mở riêng trong Studio. Prop `draft` mặc định false; bật chỉ khi muốn ghi “BẢN XEM TRƯỚC”.

## Âm thanh

- `public/audio/voice-original.mp3`: bản gốc người dùng cung cấp.
- `voice-processed.wav`: tăng tốc 1.15× bằng atempo (giữ cao độ), lọc trầm, cân âm hai lượt; dài 47.13675 s.
- `music.wav`, `sfx.wav`: âm thanh tự tạo bằng mã, không dùng sample hay âm thanh từ video tham khảo.
- `mix.wav`: stereo 50 s, voice + nhạc tự giảm theo lời nói + hiệu ứng; đây là file dùng trực tiếp trong composition.
- `mix-preview.mp3`: bản nghe thử của cùng mix.

Các file đã được đóng gói sẵn. Để tạo lại:

```bash
python scripts/process_voice.py
python scripts/make_audio.py
python scripts/mix_audio.py
```

Đổi mức nhạc, sfx, ducking trong scripts/mix_audio.py. Prop `voiceFile` trỏ đến **bản mix**, không phải voice riêng. Nội dung bản thu không bị cắt hay thay câu.

## Lời đọc và căn cảnh

`docs/loi-doc.txt` chứa kịch bản chữ người dùng cung cấp để tự thu lại, chưa phải phiên âm đã đối chiếu từng từ với MP3. `loi-doc-de-xuat.txt` là phương án thay thế khi muốn thu lại một số câu hứa hẹn quá mức. Bản voice hiện giữ nguyên lời; chữ trên hình bổ sung các lưu ý.

`docs/chia-canh.md` và `user-voice-cues.json` chứa bảng cảnh và mốc. Thời gian video = mốc nguồn / 1.15, làm tròn đến frame gần nhất. Không có ASR từng từ; độ chính xác mốc dựa trên bảng giây nguyên người dùng gửi.

## Kiểm tra và bàn giao

`docs/kiem-tra-logo.md` ghi kiểm tra bản logo mới; `metadata-final.json` ghi thông số MP4 thực tế sau render. Những báo cáo v1/v2 trong docs là lịch sử các bản trước. Gói source bao gồm đúng logo, voice, mix và các script dùng cho bản xuất.

Các lời lưu ý trong video có tính giáo dục, không bảo đảm được duyệt quảng cáo và chưa xác minh pháp lý cho sản phẩm cụ thể. Không bổ sung số liệu hoặc trích dẫn nghiên cứu.
