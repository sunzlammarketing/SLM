"""Normalize the supplied 3K voice, speed +15% while preserving pitch.
Keeps the original untouched. Requires FFmpeg.
"""
import subprocess,json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
original=root/'public/audio/voice-original.mp3'
destination=root/'public/audio/voice-processed.wav'
base='atempo=1.15,highpass=f=70'
measure=subprocess.run(['ffmpeg','-hide_banner','-i',str(original),'-af',base+',loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
stats=json.loads(re.findall(r'\{[^{}]*\}',measure.stderr)[-1])
norm='loudnorm=I=-16:TP=-1.5:LRA=7:measured_I={input_i}:measured_TP={input_tp}:measured_LRA={input_lra}:measured_thresh={input_thresh}:offset={target_offset}:linear=false:print_format=json'.format(**stats)
result=subprocess.run(['ffmpeg','-y','-hide_banner','-i',str(original),'-af',base+','+norm+',afade=t=out:st=47.15:d=0.05','-ar','48000','-ac','1',str(destination)],capture_output=True,text=True,check=True)
report={'speed':1.15,'pitch_preserved':True,'first_pass':stats,'second_pass':json.loads(re.findall(r'\{[^{}]*\}',result.stderr)[-1])}
(root/'docs/voice-processing.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,indent=2))
print(destination)
