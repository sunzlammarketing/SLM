"""Mix supplied narration, original bed and original cues. Requires FFmpeg.
Voice drives music ducking. No narration is synthesized or replaced.
"""
import subprocess,json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
a=root/'public/audio'
filters='[0:a]apad=whole_dur=50,atrim=0:50,asplit=2[voice][control];[1:a]volume=0.7[bed];[bed][control]sidechaincompress=threshold=0.035:ratio=5:attack=20:release=350:makeup=1[duck];[2:a]volume=0.18[cues];[voice][duck][cues]amix=inputs=3:duration=longest:normalize=0,alimiter=limit=0.87:level=false:latency=true,atrim=0:50[out]'
subprocess.run(['ffmpeg','-y','-v','error','-i',str(a/'voice-processed.wav'),'-i',str(a/'music.wav'),'-i',str(a/'sfx.wav'),'-filter_complex',filters,'-map','[out]','-ar','48000','-ac','2',str(a/'mix.wav')],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(a/'mix.wav'),'-c:a','libmp3lame','-b:a','192k',str(a/'mix-preview.mp3')],check=True)
p=subprocess.run(['ffmpeg','-hide_banner','-i',str(a/'mix.wav'),'-af','loudnorm=I=-16:TP=-1:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
measurement=json.loads(re.findall(r'\{[^{}]*\}',p.stderr)[-1])
(root/'docs/mix-loudness.json').write_text(json.dumps({'actualIntegratedLUFS':measurement['input_i'],'actualTruePeakDBTP':measurement['input_tp'],'actualLRA':measurement['input_lra'],'musicGainBeforeDucking':0.7,'sfxGain':0.18,'durationSeconds':50,'ducking':'voice-driven sidechain compression; threshold .035, ratio 5, attack 20ms, release 350ms'},indent=2)+'\n')
print('Mix complete:',measurement['input_i'],'LUFS;',measurement['input_tp'],'dBTP')
