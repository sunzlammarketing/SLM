"""Original procedural bed and soft cues; no third-party samples."""
import math, wave, array
from pathlib import Path
SR=48000
D=50
out=Path(__file__).resolve().parents[1]/'public'/'audio'
out.mkdir(parents=True,exist_ok=True)
def save(name,samples):
 with wave.open(str(out/name),'wb') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes(array.array('h',(int(max(-.98,min(.98,x))*32767) for x in samples)).tobytes())
# Soft C / Am / F / G major-sixth voicings. Hand-authored, generated here.
chords=[(130.8128,164.8138,195.9977,261.6256),(110,164.8138,220,261.6256),(87.3071,130.8128,174.6141,220),(97.9989,146.8324,195.9977,246.9417)]
bed=array.array('f',[0])*(SR*D)
for i in range(SR*D):
 t=i/SR
 chord=chords[int(t/4)%4]
 fade=min(1,t/1.5,(D-t)/2)
 pad=sum(math.sin(2*math.pi*hz*t)*.025 for hz in chord)
 beat=t%0.5
 note=chord[int(t/.5)%4]*2
 pluck=math.sin(2*math.pi*note*beat)*math.exp(-beat*12)*.045
 bed[i]=(pad+pluck)*max(0,fade)
save('music.wav',bed)
sfx=array.array('f',[0])*(SR*D)
for start in [313/60,730/60,1304/60,1930/60,2400/60,2661/60]:
 for i in range(int(.22*SR)):
  t=i/SR; envelope=math.sin(math.pi*t/.22)**2
  sfx[int(start*SR)+i]+=.14*envelope*(math.sin(2*math.pi*(600*t+900*t*t))+.3*math.sin(2*math.pi*1200*t))
save('sfx.wav',sfx)
print('Generated original music.wav and sfx.wav, 50 s / 48 kHz PCM.')
